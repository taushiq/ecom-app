// module.exports = {
//     host: 'localhost',
//     port: 3306,
//     database: 'ecomm_app',
//     user: 'root',
//     password: 'Admin@123'
// };

//remote
// module.exports = {
//     host: 'remotemysql.com',
//     port: 3306,
//     database: '5PJ8RGg4yy',
//     user: '5PJ8RGg4yy',
//     password: 'Y7VsxHDGyN'
// };

//Hosting
module.exports = {
    host: 'localhost',
    database: 'tausglth_ecom_app',
    user: 'tausglth_ecom_app_user',
    password: 'ecom@ecom'
};